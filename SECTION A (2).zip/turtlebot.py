import rospy 
from geometry_msgs.msg import Twist
import sys

def move turtle(line_vel, ang_vel);
rospy.init_nofr('turtlemove,anonymous=true)
pub = rospy.Publisher(;/turtle1/cmd_vel,Twist, queue size = 10)
rate = rospy.Rate(10)

vel= Twist()
while true;
vel.linear.x=line_vel
vel.linear.y=0
vel.linear.z=0

vel.angular.x=0
vel.linear.y=o
vel.angular.z=ang_vel

rospy.loginfo("Linear Value is -->%f: Angular")

pub.publish(vel)
rate.sleep()

if_name_=='_main_:
try:
move_turtle(float(sys.argv[1],float9sys.argv[2]))
except rospy.ROSInterruptException:
pass
